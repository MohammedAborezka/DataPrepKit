# -*- coding: utf-8 -*-
"""
Created on Fri Feb 16 18:27:39 2024

@author: MOHAMMED
"""

from setuptools import setup, find_packages
setup(
name='DataPrepKit5.6',
version='0.1.0',
author='Aborezka',
author_email='MohammedAborezka@gmail.com',
description='this package help you anlayze your data file insted of its type',
packages=find_packages(),
classifiers=[
'Programming Language :: Python :: 3',
'License :: OSI Approved :: MIT License',
'Operating System :: OS Independent',
],
python_requires='>=3.6',
)